import os.path
import subprocess

def main():
	files = subprocess.Popen(['ls'], stdout=subprocess.PIPE)
	files_array = files.communicate()[0].decode().split('\n')
	for file in files_array:
		if (".csv" or ".log" or ".kismet") in file:
			subprocess.call(['rm', file], stdout = subprocess.DEVNULL)

if __name__ == '__main__':
	main()